# Complete Setup & Deployment Guide - Project Management App

## 🚀 QUICK START (5 MINUTES)

### Step 1: Install Python (if not already installed)

Go to https://www.python.org/downloads/ and download Python 3.9+

### Step 2: Clone/Download Project

```bash
cd your-projects-folder
git clone <your-repo-url>
cd project-management-app
```

### Step 3: Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python -m venv venv
source venv/bin/activate
```

### Step 4: Install Dependencies

```bash
pip install -r requirements.txt
pip install gunicorn  # For deployment
```

### Step 5: Run Backend

```bash
python app.py
```

You should see:
```
 * Running on http://127.0.0.1:5000
```

**KEEP THIS TERMINAL OPEN** ✅

### Step 6: Run Frontend (New Terminal Tab)

```bash
# Windows
python -m http.server 8000

# macOS/Linux
python -m http.server 8000
```

### Step 7: Open in Browser

Go to: `http://localhost:8000`

✅ **You're done! Test the app:**
- Sign up with an email
- Create a project
- Add tasks
- Edit/delete them

---

## 📦 DEPLOYMENT GUIDE (30 MINUTES)

### Option 1: Deploy on Render.com (EASIEST) ⭐

#### Step 1: Create GitHub Repository

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/project-management-app.git
git push -u origin main
```

#### Step 2: Sign Up on Render

Go to https://render.com and sign up (free account)

#### Step 3: Create New Web Service

1. Click "New +" → "Web Service"
2. Connect your GitHub repository
3. Fill in details:
   - **Name**: `project-management-app`
   - **Runtime**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`

#### Step 4: Add Environment Variables

Click "Advanced" and add:

```
DATABASE_URL = postgresql://...  (Render will provide this)
JWT_SECRET_KEY = your-super-secret-key-change-this-12345
FLASK_ENV = production
```

#### Step 5: Create PostgreSQL Database (Free)

1. In Render Dashboard, click "New +" → "PostgreSQL"
2. Create database
3. Copy connection string into `DATABASE_URL`

#### Step 6: Deploy

Click "Create Web Service" and wait 3-5 minutes

✅ You'll get a live URL like: `https://project-management-app.onrender.com`

#### Step 7: Update Frontend API URL

In `index.html`, change:
```javascript
const API_URL = 'https://project-management-app.onrender.com/api';
```

#### Step 8: Deploy Frontend

Option A: GitHub Pages
```bash
# Push index.html to GitHub Pages branch
git checkout --orphan gh-pages
git rm -rf .
git add index.html
git commit -m "Deploy frontend"
git push origin gh-pages
```

Then update API URL in the GitHub Pages version.

Option B: Render Static Site
1. Push frontend to separate `frontend` branch
2. Create Static Site in Render pointing to `index.html`

---

### Option 2: Deploy on Railway.app

#### Step 1: Push to GitHub (same as above)

#### Step 2: Sign Up on Railway

Go to https://railway.app and sign up with GitHub

#### Step 3: New Project

Click "New Project" → "Deploy from GitHub repo"

Select your `project-management-app` repository

#### Step 4: Add Services

Railway auto-detects Flask. Just add PostgreSQL plugin:
- Click "Add" → select "PostgreSQL"

#### Step 5: Set Environment Variables

In Variables tab:
```
JWT_SECRET_KEY=your-super-secret-key-12345
FLASK_ENV=production
DATABASE_URL=<Railway provides this automatically>
```

#### Step 6: Deploy

Railway auto-deploys when you push to GitHub

✅ Get public URL and update frontend API_URL

---

### Option 3: Deploy on Heroku (Free Tier Deprecated, Use Above)

---

## 🔧 PRODUCTION CHECKLIST

Before deploying, complete these:

- [ ] Change `JWT_SECRET_KEY` in `.env`
- [ ] Switch to PostgreSQL (not SQLite)
- [ ] Set `FLASK_ENV=production`
- [ ] Test all features
- [ ] Add input validation
- [ ] Enable HTTPS (automatic on Render/Railway)
- [ ] Update frontend API URL
- [ ] Test on mobile
- [ ] Add password strength requirements

---

## 🐛 TROUBLESHOOTING

### Backend Error: "ModuleNotFoundError"

```bash
pip install -r requirements.txt
```

### CORS Error in Browser Console

Add to `app.py`:
```python
CORS(app, origins=["http://localhost:8000", "https://your-frontend-url.com"])
```

### Database Connection Error

Check `.env` file:
```env
DATABASE_URL=sqlite:///project_manager.db
```

### Port Already in Use

```bash
# Kill process on port 5000
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# macOS/Linux
lsof -i :5000
kill -9 <PID>
```

### JWT Token Expired

Users need to login again. For longer tokens, update in `app.py`:
```python
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=30)
```

---

## 📚 API TESTING (Postman)

### Test Signup

```
POST http://localhost:5000/api/auth/signup
Body (JSON):
{
  "username": "testuser",
  "email": "test@example.com",
  "password": "password123"
}
```

Response:
```json
{
  "access_token": "eyJ0eXAi...",
  "user": { "id": 1, "username": "testuser" }
}
```

### Test Login

```
POST http://localhost:5000/api/auth/login
Body (JSON):
{
  "email": "test@example.com",
  "password": "password123"
}
```

### Create Project (Protected)

```
POST http://localhost:5000/api/projects
Headers:
  Authorization: Bearer <token>
Body (JSON):
{
  "title": "My Project",
  "description": "Project description"
}
```

---

## 🎯 FOLDER STRUCTURE FOR GITHUB

```
project-management-app/
│
├── app.py                    # Flask backend
├── index.html               # Frontend
├── requirements.txt         # Python dependencies
├── .env                     # Environment variables
├── .gitignore              # Git ignore
├── .env.example            # Example env variables
├── Procfile                # For Heroku
├── render.yaml             # For Render
├── README.md               # Documentation
└── SETUP_GUIDE.md          # This file
```

---

## ✅ FINAL CHECKLIST

### Before Submitting:

- [ ] Code is clean and commented
- [ ] README.md is complete
- [ ] .gitignore is set up
- [ ] No sensitive data in GitHub
- [ ] Backend runs locally
- [ ] Frontend runs locally
- [ ] All CRUD operations work
- [ ] Authentication works
- [ ] Deployed on Render/Railway/Heroku
- [ ] Frontend connects to live backend
- [ ] GitHub repo is public
- [ ] Deployment link works

---

## 📝 GITHUB SUBMISSION

```
GitHub Repo: https://github.com/YOUR-USERNAME/project-management-app
Deployed Website: https://project-management-app.onrender.com
```

---

## 🎓 WHAT YOU LEARNED

✅ Backend development (Flask)
✅ Database design & relationships
✅ User authentication & JWT
✅ RESTful API design
✅ Frontend-Backend integration
✅ Deployment & DevOps basics
✅ Git & GitHub version control
✅ Security best practices

---

## 🚀 NEXT STEPS (After Submission)

1. Add team collaboration features
2. Implement due dates & reminders
3. Add file attachments
4. Create mobile app
5. Add email notifications
6. Implement webhooks
7. Add API rate limiting
8. Create admin panel

---

Good luck! 🎉
