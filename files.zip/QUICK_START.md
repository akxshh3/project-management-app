# 🚀 PROJECT MANAGEMENT APP - QUICK START

## What You Have

A complete **full-stack project management application** with:
- ✅ User authentication (signup/login)
- ✅ Create/edit/delete projects
- ✅ Create/edit/delete tasks
- ✅ Beautiful responsive UI
- ✅ Secure JWT-based authentication
- ✅ SQLite database (easily upgradeable to PostgreSQL)
- ✅ Ready to deploy

---

## ⚡ START IN 5 MINUTES

### 1. Install Python
Download from https://www.python.org/downloads/ (Python 3.9+)

### 2. Open Terminal/CMD and Run:

```bash
# Navigate to project folder
cd project-management-app

# Create virtual environment
python -m venv venv

# Activate it
# On Windows: venv\Scripts\activate
# On Mac/Linux: source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run backend
python app.py
```

**Keep terminal open!** ✅

### 3. Open New Terminal Tab and Run:

```bash
# Make sure you're in project folder
python -m http.server 8000
```

### 4. Open Browser

Go to: `http://localhost:8000`

✅ **DONE!** Sign up and test it.

---

## 📁 FILES EXPLAINED

| File | Purpose |
|------|---------|
| `app.py` | Flask backend with all API endpoints |
| `index.html` | Complete frontend (HTML/CSS/JS) |
| `requirements.txt` | Python dependencies |
| `.env` | Environment variables |
| `README.md` | Full documentation |
| `SETUP_GUIDE.md` | Detailed setup & deployment |

---

## 🎯 WHAT EACH FILE DOES

### `app.py` (Backend)
- Handles user signup/login
- Creates/edits/deletes projects
- Creates/edits/deletes tasks
- Manages database
- Provides API endpoints

### `index.html` (Frontend)
- Login/signup forms
- Project dashboard
- Task management UI
- All styling included
- Works on desktop & mobile

### `requirements.txt`
```
Flask==2.3.3              # Web framework
Flask-SQLAlchemy==3.0.5   # Database
Flask-Bcrypt==1.0.1       # Password hashing
Flask-JWT-Extended==4.5.2 # Authentication
Flask-CORS==4.0.0         # Cross-origin requests
```

---

## 🔐 AUTHENTICATION FLOW

```
User Signs Up
    ↓
Password is hashed with Bcrypt
    ↓
User saved to database
    ↓
JWT token created
    ↓
Token sent to frontend (localStorage)
    ↓
Token used for all future requests
```

---

## 📊 DATABASE STRUCTURE

### Users
- Store username, email, hashed password
- Each user has many projects

### Projects
- Title, description, created by user_id
- Each project has many tasks

### Tasks
- Title, description, status, priority
- Belongs to one project

```
User
 └─ Project
     └─ Task
```

---

## 🌐 API ENDPOINTS (Backend)

### Authentication
- `POST /api/auth/signup` - Create account
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user

### Projects
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create project
- `GET /api/projects/<id>` - Get project details
- `PUT /api/projects/<id>` - Update project
- `DELETE /api/projects/<id>` - Delete project

### Tasks
- `POST /api/projects/<id>/tasks` - Create task
- `PUT /api/tasks/<id>` - Update task
- `DELETE /api/tasks/<id>` - Delete task

---

## 🚀 DEPLOY IN 10 MINUTES (Render.com)

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/project-management-app.git
git push -u origin main
```

### Step 2: Go to https://render.com
- Sign up with GitHub
- Click "New" → "Web Service"
- Select your repository
- Set Name: `project-management-app`
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app`

### Step 3: Add PostgreSQL Database
- Click "New" → "PostgreSQL"
- Copy connection string

### Step 4: Set Environment Variables
- `DATABASE_URL` = PostgreSQL connection string
- `JWT_SECRET_KEY` = any random string
- `FLASK_ENV` = production

### Step 5: Click Deploy!
Wait 3-5 minutes → Get live URL ✅

### Step 6: Update Frontend
In `index.html` line 1:
```javascript
const API_URL = 'https://your-app.onrender.com/api';
```

Push to GitHub → Render auto-deploys frontend

---

## 🎓 KEY CONCEPTS YOU'LL LEARN

1. **Backend Development** - Flask framework
2. **Database** - SQLAlchemy ORM, relationships
3. **Authentication** - JWT tokens, password hashing
4. **API Design** - RESTful endpoints
5. **Frontend Integration** - Fetch API, localStorage
6. **Deployment** - Production servers
7. **Security** - Password hashing, token management

---

## ⚠️ BEFORE DEPLOYMENT

- [ ] Change `JWT_SECRET_KEY` in `.env`
- [ ] Switch to PostgreSQL (not SQLite)
- [ ] Set `FLASK_ENV=production`
- [ ] Test all features work
- [ ] Update API URL in `index.html`
- [ ] No sensitive data in GitHub

---

## 🛠️ COMMON ISSUES & FIXES

### "No module named flask"
```bash
pip install -r requirements.txt
```

### "Port 5000 already in use"
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Mac/Linux
lsof -i :5000
kill -9 <PID>
```

### "CORS error in console"
- Ensure backend is running on port 5000
- Check `CORS(app)` in app.py is enabled

### "Can't login"
- Check email & password correct
- Check database has users
- Check JWT token in browser DevTools (F12 → Application → localStorage)

---

## 📦 FOLDER STRUCTURE FOR GITHUB

```
project-management-app/
├── app.py              ← Backend
├── index.html          ← Frontend
├── requirements.txt    ← Python packages
├── .env               ← Secrets (don't commit!)
├── .gitignore         ← Ignore files
├── .env.example       ← Example env vars
├── README.md          ← Documentation
├── SETUP_GUIDE.md     ← Detailed guide
├── Procfile           ← For Heroku
└── render.yaml        ← For Render
```

---

## ✅ SUBMISSION CHECKLIST

Before turning in:

- [ ] Clone your GitHub repo fresh to test it works
- [ ] Backend runs with `python app.py`
- [ ] Frontend opens at `http://localhost:8000`
- [ ] Can signup/login
- [ ] Can create/edit/delete projects
- [ ] Can create/edit/delete tasks
- [ ] Deployed on Render/Railway/Heroku (live URL)
- [ ] Frontend connects to live backend
- [ ] GitHub repo is public
- [ ] README.md explains everything
- [ ] No `__pycache__`, `.env`, or `*.db` files in GitHub

---

## 🎯 WHAT TO SUBMIT

### Required:
1. **GitHub Repository Link**
   - All code, clean structure
   - Good README
   - Working .gitignore

2. **Deployed Website Link**
   - Live, working version
   - Can signup/login
   - Can manage projects and tasks

Example:
```
GitHub: https://github.com/your-username/project-management-app
Live: https://project-management-app.onrender.com
```

---

## 🚀 NEXT FEATURES (AFTER SUBMISSION)

- [ ] Team collaboration (share projects)
- [ ] Due dates & reminders
- [ ] File attachments
- [ ] Comments on tasks
- [ ] Activity log
- [ ] Dark mode
- [ ] Email notifications
- [ ] Mobile app

---

## 💡 TIPS

1. **Keep it simple** - More features = more bugs
2. **Test everything** - signup, login, CRUD operations
3. **Clean code** - Add comments, organize files
4. **Document well** - README should explain everything
5. **Security first** - Change secret keys, use strong passwords
6. **Deploy early** - Deploy after backend works, not at the end

---

## 🆘 NEED HELP?

Check these in order:
1. Browser console (F12 → Console tab)
2. Backend terminal output
3. README.md and SETUP_GUIDE.md
4. Google the error message
5. Stack Overflow

---

## 🎉 YOU'VE GOT THIS!

You now have everything needed for a professional portfolio project:
✅ Full-stack application
✅ User authentication
✅ Database integration
✅ Deployed live website
✅ Clean GitHub repository

**Time to submit and show off!** 🚀
