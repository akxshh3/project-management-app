# 🏗️ SYSTEM ARCHITECTURE

## Overall Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     USER BROWSER                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  index.html (Frontend - Single Page Application)     │   │
│  │  ┌────────────────────────────────────────────────┐  │   │
│  │  │  • Login/Signup Forms                          │  │   │
│  │  │  • Project Dashboard                           │  │   │
│  │  │  • Task Management UI                          │  │   │
│  │  │  • Beautiful CSS Styling                       │  │   │
│  │  │  • JavaScript Event Handlers                   │  │   │
│  │  └────────────────────────────────────────────────┘  │   │
│  └────────────────────────────────────────────────────────┘  │
│                          ↓ (HTTP Requests)                    │
│                    API Endpoints (REST)                       │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                    BACKEND SERVER                            │
│              (Python Flask on Port 5000)                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  app.py - Main Flask Application                    │   │
│  │                                                       │   │
│  │  AUTH ROUTES                                         │   │
│  │  ├── POST /api/auth/signup                          │   │
│  │  ├── POST /api/auth/login                           │   │
│  │  └── GET /api/auth/me                               │   │
│  │                                                       │   │
│  │  PROJECT ROUTES                                      │   │
│  │  ├── GET /api/projects (list)                       │   │
│  │  ├── POST /api/projects (create)                    │   │
│  │  ├── GET /api/projects/<id> (detail)                │   │
│  │  ├── PUT /api/projects/<id> (update)                │   │
│  │  └── DELETE /api/projects/<id>                      │   │
│  │                                                       │   │
│  │  TASK ROUTES                                         │   │
│  │  ├── POST /api/projects/<id>/tasks (create)         │   │
│  │  ├── PUT /api/tasks/<id> (update)                   │   │
│  │  └── DELETE /api/tasks/<id>                         │   │
│  │                                                       │   │
│  │  MIDDLEWARE                                          │   │
│  │  ├── CORS (Cross-Origin Requests)                   │   │
│  │  ├── JWT Authentication (@jwt_required)             │   │
│  │  └── Error Handling                                 │   │
│  └──────────────────────────────────────────────────────┘   │
│                          ↓ (ORM Queries)                     │
│                    SQLAlchemy Models                         │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                   DATABASE LAYER                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  SQLite (Development) / PostgreSQL (Production)      │   │
│  │                                                       │   │
│  │  Tables:                                             │   │
│  │  ┌──────────────┐                                    │   │
│  │  │ USERS        │                                    │   │
│  │  ├──────────────┤                                    │   │
│  │  │ id (PK)      │ ────────────┐                      │   │
│  │  │ username     │             │                      │   │
│  │  │ email        │             │ (1 to Many)          │   │
│  │  │ password     │             │                      │   │
│  │  │ created_at   │             │                      │   │
│  │  └──────────────┘             │                      │   │
│  │                               ↓                      │   │
│  │  ┌──────────────┐    ┌──────────────┐               │   │
│  │  │ PROJECTS     │    │ TASKS        │               │   │
│  │  ├──────────────┤    ├──────────────┤               │   │
│  │  │ id (PK)      │    │ id (PK)      │               │   │
│  │  │ title        │    │ title        │               │   │
│  │  │ description  │    │ description  │               │   │
│  │  │ user_id (FK) │───→│ project_id   │               │   │
│  │  │ created_at   │    │ status       │               │   │
│  │  │ updated_at   │    │ priority     │               │   │
│  │  └──────────────┘    │ created_at   │               │   │
│  │       ↑               │ updated_at   │               │   │
│  │       │(1 to Many)    └──────────────┘               │   │
│  │       └─────────────────────────────┘               │   │
│  │                                                       │   │
│  │  Relationships:                                      │   │
│  │  • 1 User → Many Projects                           │   │
│  │  • 1 Project → Many Tasks                           │   │
│  │  • User deletes → Projects & Tasks cascade delete   │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram

### 1. User Signup Flow

```
Frontend                        Backend                    Database
┌────────────┐                 ┌────────────┐            ┌────────────┐
│ User enters│                 │ Receives   │            │ SQLite/    │
│ signup form│                 │ POST req   │            │ PostgreSQL │
└──────┬─────┘                 └──────┬─────┘            └────────────┘
       │                              │
       │ POST /auth/signup            │
       │ (username, email, password)  │
       │─────────────────────────────→│
       │                              │ ✓ Validate input
       │                              │ ✓ Hash password (bcrypt)
       │                              │ ✓ Check for duplicates
       │                              │
       │                              │ Create new User record
       │                              │─────────────────────→│
       │                              │                      │ Save to DB
       │                              │                      │←─────────
       │                              │ ✓ Create JWT token
       │                              │
       │ 201 + access_token           │
       │←─────────────────────────────│
       │
       │ Save token to localStorage
       │ Show dashboard
```

### 2. Create Project Flow

```
Frontend                        Backend                    Database
┌────────────┐                 ┌────────────┐            ┌────────────┐
│ User clicks│                 │ Verifies   │            │ Projects   │
│ "New Proj" │                 │ JWT token  │            │ Table      │
└──────┬─────┘                 └──────┬─────┘            └────────────┘
       │                              │
       │ POST /projects               │
       │ Headers: Authorization       │
       │ Body: {title, description}   │
       │─────────────────────────────→│
       │                              │ ✓ Validate JWT
       │                              │ ✓ Get user_id from token
       │                              │ ✓ Validate input
       │                              │
       │                              │ Create Project with user_id
       │                              │─────────────────────→│
       │                              │                      │ Insert
       │                              │                      │←─────
       │                              │ ✓ Return project
       │                              │
       │ 201 + project object         │
       │←─────────────────────────────│
       │
       │ Add to project list display
```

### 3. Create Task Flow

```
Frontend                        Backend                    Database
┌────────────┐                 ┌────────────┐            ┌────────────┐
│ User in    │                 │ Verifies   │            │ Tasks      │
│ project    │                 │ ownership  │            │ Table      │
│ clicks new │                 │            │            │            │
│ task button│                 │            │            │            │
└──────┬─────┘                 └──────┬─────┘            └────────────┘
       │                              │
       │ POST /projects/<id>/tasks    │
       │ {title, status, priority...} │
       │─────────────────────────────→│
       │                              │ ✓ Verify user owns project
       │                              │ ✓ Validate input
       │                              │ ✓ Get user_id from JWT
       │                              │
       │                              │ Create Task with project_id
       │                              │─────────────────────→│
       │                              │                      │ Insert
       │                              │                      │←─────
       │                              │ ✓ Return task
       │                              │
       │ 201 + task object            │
       │←─────────────────────────────│
       │
       │ Add to task list display
```

---

## Authentication Flow (JWT)

```
User                Frontend              Backend            Database
 │                    │                    │                    │
 │  1. Sign Up        │                    │                    │
 ├──────────────────→ │                    │                    │
 │                    │ POST /auth/signup  │                    │
 │                    ├──────────────────→ │                    │
 │                    │                    │ Hash password      │
 │                    │                    │ Save to DB         │
 │                    │                    ├───────────────────→│
 │                    │                    │                    │
 │                    │ 2. Create JWT Token│                    │
 │                    │ ←──────────────────┤                    │
 │                    │                    │                    │
 │ 3. Save Token      │                    │                    │
 │ (localStorage)     │                    │                    │
 │←──────────────────┤                    │                    │
 │                    │                    │                    │
 │ 4. Make Requests   │                    │                    │
 ├──────────────────→ │                    │                    │
 │                    │ GET /projects      │                    │
 │                    │ Headers:           │                    │
 │                    │ Auth: Bearer <JWT> │                    │
 │                    ├──────────────────→ │                    │
 │                    │                    │ Verify JWT         │
 │                    │                    │ ✓ Token valid      │
 │                    │                    │ ✓ Not expired      │
 │                    │                    │                    │
 │                    │ Return data        │                    │
 │                    │ ←──────────────────┤                    │
 │                    │                    │                    │
```

---

## Security Layers

```
┌────────────────────────────────────────────────┐
│           FRONTEND SECURITY                     │
│  • Token stored in localStorage                │
│  • Token sent in Authorization header          │
│  • CORS prevents cross-origin attacks          │
│  • Form validation                             │
└────────────────────────────────────────────────┘
                       ↓
┌────────────────────────────────────────────────┐
│           NETWORK SECURITY (HTTPS)              │
│  • Encryption in transit (production)           │
│  • No sensitive data in URL                     │
└────────────────────────────────────────────────┘
                       ↓
┌────────────────────────────────────────────────┐
│           BACKEND SECURITY                      │
│  • CORS validation                             │
│  • JWT token verification                      │
│  • User ownership validation                   │
│  • SQL injection prevention (ORM)              │
│  • Password hashing (bcrypt)                   │
└────────────────────────────────────────────────┘
                       ↓
┌────────────────────────────────────────────────┐
│           DATABASE SECURITY                     │
│  • Hashed passwords (not plaintext)            │
│  • Foreign key constraints                     │
│  • User isolation (cascading deletes)          │
└────────────────────────────────────────────────┘
```

---

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                  PRODUCTION DEPLOYMENT                  │
│                     (Render.com)                         │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────┐    ┌──────────────────┐          │
│  │  Web Service     │    │  PostgreSQL DB   │          │
│  │  (Python/Flask)  │    │  (Managed)       │          │
│  │  ├─ gunicorn     │    │  ├─ Backups      │          │
│  │  ├─ WSGI Server  │    │  ├─ Replication  │          │
│  │  └─ Auto scale   │    │  └─ Security     │          │
│  └────────┬─────────┘    └────────┬─────────┘          │
│           │                       │                      │
│           └───────────────────────┘                      │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Environment Variables                            │  │
│  │ • DATABASE_URL = PostgreSQL connection string    │  │
│  │ • JWT_SECRET_KEY = (secure, change from dev)    │  │
│  │ • FLASK_ENV = production                        │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Git Integration (Auto-deploy)                    │  │
│  │ Push to GitHub → Render detects → Auto deploy   │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Frontend (Separate Deployment or Same Server)    │  │
│  │ Option 1: GitHub Pages                          │  │
│  │ Option 2: Render Static Site                    │  │
│  │ Option 3: Serve from Flask (app.static_files)   │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## Technology Stack Summary

```
FRONTEND
├── HTML5 - Structure
├── CSS3 - Styling & Responsive Design
└── Vanilla JavaScript - No framework needed
    ├── Fetch API - HTTP requests
    ├── localStorage - Token storage
    └── DOM manipulation - UI updates

BACKEND
├── Flask - Web framework
├── Flask-SQLAlchemy - ORM
├── Flask-JWT-Extended - Authentication
├── Flask-Bcrypt - Password hashing
├── Flask-CORS - Cross-origin requests
└── Werkzeug - WSGI utilities

DATABASE
├── SQLite - Development (file-based)
└── PostgreSQL - Production (cloud-hosted)

DEPLOYMENT
├── Render.com - Server hosting
├── GitHub - Version control
├── Git - Version management
└── gunicorn - WSGI HTTP Server

SECURITY
├── JWT Tokens - Authentication
├── Bcrypt - Password hashing
├── CORS - Request validation
├── ORM - SQL injection prevention
└── HTTPS - Encryption
```

---

## Data Relationships

```
                    ┌─────────────────┐
                    │     USER        │
                    │   (1 entity)    │
                    ├─────────────────┤
                    │ id              │
                    │ username        │
                    │ email           │
                    │ password (hash) │
                    │ created_at      │
                    └────────┬────────┘
                             │
                    ┌────────┴────────┐
                    │  (1 to Many)    │
                    │  user_id (FK)   │
                    ▼                 ▼
            ┌──────────────┐    ┌──────────────┐
            │  PROJECT     │    │  PROJECT     │
            │  (Project 1) │    │  (Project 2) │
            ├──────────────┤    ├──────────────┤
            │ id           │    │ id           │
            │ title        │    │ title        │
            │ description  │    │ description  │
            │ user_id (FK) │    │ user_id (FK) │
            │ created_at   │    │ created_at   │
            └────────┬─────┘    └────────┬─────┘
                     │                   │
          ┌──────────┴──────────┐        │
          │  (1 to Many)        │        │
          │  project_id (FK)    │        │
          ▼                     ▼        ▼
        ┌──────┐             ┌──────┐ ┌──────┐
        │TASK 1│             │TASK 2│ │TASK 3│
        ├──────┤             ├──────┤ ├──────┤
        │title │             │title │ │title │
        │desc  │             │desc  │ │desc  │
        │status│             │status│ │status│
        │prio  │             │prio  │ │prio  │
        └──────┘             └──────┘ └──────┘
```

---

## Error Handling Flow

```
Frontend Request
       │
       ▼
    ┌─────────────────────┐
    │ Backend Receives    │
    │ Request             │
    └──────────┬──────────┘
               │
        ┌──────┴──────┐
        │             │
        ▼             ▼
    ┌────────┐  ┌──────────────┐
    │ Valid? │  │ Valid JWT?   │
    └────┬───┘  └──────┬───────┘
         │             │
      NO│             │NO
        │      ┌──────┴──────┐
        │      ▼             ▼
        │  ┌────────┐  ┌──────────┐
        │  │400     │  │401       │
        │  │Bad Req │  │Unauth    │
        │  └────────┘  └──────────┘
        │
        ▼
    ┌──────────────────┐
    │ Process Request  │
    │ (DB operations)  │
    └────────┬─────────┘
             │
        ┌────┴────┐
        │          │
      YES│         │NO (Error)
        │          │
        ▼          ▼
    ┌────────┐  ┌──────────────┐
    │200 OK  │  │500           │
    │+ data  │  │Server Error  │
    └────────┘  └──────────────┘
```

---

This architecture is:
✅ **Scalable** - Easy to add features
✅ **Secure** - JWT, password hashing, CORS
✅ **Maintainable** - Clear separation of concerns
✅ **Production-Ready** - Deployable immediately
✅ **Learning-Friendly** - Good practices throughout
