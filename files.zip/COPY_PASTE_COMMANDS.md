# 💻 COPY-PASTE COMMANDS

Just copy these commands one by one. Don't skip steps!

---

## 🏃 QUICK LOCAL SETUP (5 MINUTES)

### Terminal 1: Backend Setup

```bash
# Navigate to your project
cd project-management-app

# Create virtual environment
python -m venv venv

# Activate virtual environment
# ⚠️ CHOOSE YOUR OS:

# Windows:
venv\Scripts\activate

# macOS/Linux:
source venv/bin/activate

# Install all dependencies
pip install -r requirements.txt

# Run the backend server
python app.py
```

**You should see:**
```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

✅ **LEAVE THIS TERMINAL OPEN**

---

### Terminal 2: Frontend Setup

```bash
# Open a NEW terminal tab/window

# Navigate to project (make sure you're in the right folder)
cd project-management-app

# Start HTTP server for frontend
python -m http.server 8000
```

**You should see:**
```
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...
```

✅ **DONE!**

---

## 🌐 OPEN IN BROWSER

```
Go to: http://localhost:8000
```

✅ Test the app!

---

## 🚀 GITHUB SETUP (BEFORE DEPLOYMENT)

### Step 1: Initialize Git

```bash
# Go to project folder
cd project-management-app

# Initialize git
git init

# Add all files
git add .

# First commit
git commit -m "Initial commit: Full-stack project management app"

# Rename branch to main
git branch -M main
```

### Step 2: Create GitHub Repository

1. Go to https://github.com/new
2. Create repository: `project-management-app`
3. **DO NOT** initialize with README
4. Click "Create repository"

### Step 3: Push Code to GitHub

```bash
# Copy the commands from GitHub's quick setup
# (They look like this, but use YOUR username):

git remote add origin https://github.com/YOUR-USERNAME/project-management-app.git
git branch -M main
git push -u origin main
```

✅ **Your code is now on GitHub!**

---

## 🌍 DEPLOY ON RENDER.COM

### Step 1: Sign Up

```
Go to: https://render.com
Sign up with GitHub
```

### Step 2: Create PostgreSQL Database

```
1. Dashboard → "New +"
2. Select "PostgreSQL"
3. Name: "project-manager-db"
4. Click "Create Database"
5. Copy the connection string (you'll need it)
```

### Step 3: Create Web Service

```
1. Dashboard → "New +"
2. Select "Web Service"
3. Connect to your GitHub repo
4. Fill in:
   - Name: project-management-app
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: gunicorn app:app
5. Click "Advanced"
```

### Step 4: Add Environment Variables

```
In "Advanced" section, add:

Key: DATABASE_URL
Value: (paste the PostgreSQL connection string)

Key: JWT_SECRET_KEY
Value: your-super-secret-key-12345-change-this

Key: FLASK_ENV
Value: production
```

### Step 5: Deploy

```
Click "Create Web Service"
Wait 3-5 minutes for deployment
```

✅ **You'll get a URL like:** `https://project-management-app.onrender.com`

### Step 6: Update Frontend API URL

In `index.html`, find line ~1063:
```javascript
const API_URL = 'http://localhost:5000/api';
```

Change to:
```javascript
const API_URL = 'https://project-management-app.onrender.com/api';
```

### Step 7: Push to GitHub

```bash
git add .
git commit -m "Update API URL for production"
git push
```

✅ **Render auto-deploys!** Wait 1-2 minutes then test your live site.

---

## 🧪 TEST DEPLOYMENT

1. Go to `https://project-management-app.onrender.com`
2. Sign up with test account
3. Create a project
4. Add some tasks
5. Edit/delete them
6. Everything works? ✅ GREAT!

---

## 🔗 FINAL SUBMISSION

You need:

**GitHub Repo:**
```
https://github.com/YOUR-USERNAME/project-management-app
```

**Live Website:**
```
https://project-management-app.onrender.com
```

---

## 🐛 TROUBLESHOOTING

### Python not found?
```
# Check Python is installed
python --version

# If not, download from https://www.python.org
```

### Module not found error?
```bash
pip install -r requirements.txt
```

### Port 5000 already in use?
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F

# Mac/Linux
lsof -i :5000
kill -9 <PID_NUMBER>
```

### Git command not found?
```
Install Git: https://git-scm.com/download
```

### Can't push to GitHub?
```bash
# Check remote is set correctly
git remote -v

# If not, set it:
git remote add origin https://github.com/YOUR-USERNAME/project-management-app.git
```

### Backend won't start?
```bash
# Make sure virtual env is activated
# Windows: venv\Scripts\activate
# Mac/Linux: source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run again
python app.py
```

---

## ✅ CHECKLIST

Before submitting:

- [ ] Backend works locally (`python app.py`)
- [ ] Frontend opens at `http://localhost:8000`
- [ ] Can signup/login
- [ ] Can create projects and tasks
- [ ] Code pushed to GitHub
- [ ] Deployed on Render (or Railway/Heroku)
- [ ] Live site works
- [ ] GitHub link works
- [ ] No sensitive data in GitHub (check .gitignore)
- [ ] README.md is complete

---

## 🎯 IF SOMETHING GOES WRONG

1. **Read the error message carefully**
2. **Google the error**
3. **Check README.md and SETUP_GUIDE.md**
4. **Check browser console (F12)**
5. **Check terminal output**
6. **Ask for help with the exact error**

---

## 💪 YOU'VE GOT THIS!

Follow these steps in order:
1. ✅ Local setup (5 min)
2. ✅ Test locally (5 min)
3. ✅ GitHub push (5 min)
4. ✅ Render deployment (5 min)
5. ✅ Test live (5 min)

**Total: ~25 minutes to full deployment!** 🚀

Good luck! 🎉
